# 🚀 QUICK START GUIDE - For Complete Beginners

This guide will help you get the quiz app running in **under 15 minutes**, even if you've never coded before!

## ⚡ Option 1: Deploy on Replit (Easiest - No Installation Required)

### Step 1: Create a Replit Account
1. Go to [replit.com](https://replit.com)
2. Click "Sign up" and create a free account

### Step 2: Import This Project
1. Click "Create Repl" button
2. Choose "Import from GitHub" 
3. Or click "Upload files" and upload this entire folder
4. Replit will automatically detect it's a React app

### Step 3: Set Up Firebase (5 minutes)
1. Open a new tab and go to [console.firebase.google.com](https://console.firebase.google.com)
2. Click "Add project"
3. Name it "quiz-app" and click Continue (disable Analytics)
4. Click "Create project"

**Enable Authentication:**
- Click "Authentication" → "Get started"
- Click "Email/Password" → Toggle ON → Save

**Enable Database:**
- Click "Firestore Database" → "Create database"
- Choose "Test mode" → Select a location → Enable

**Get Your Config:**
- Click the gear icon ⚙️ → "Project settings"
- Scroll down → Click the web icon `</>`
- Name it "QuizApp" → Copy the config code

### Step 4: Configure Your App
1. In Replit, open `src/firebase.js`
2. Replace the placeholder values with your Firebase config
3. Click "Run" button at the top

### Step 5: Test Your App! 🎉
1. Click "Open in new tab" button
2. Sign up with a test email
3. Take the quiz
4. Check the leaderboard

**Done! Your app is now live on the internet!**

---

## 💻 Option 2: Run Locally on Your Computer

### Prerequisites
- Install [Node.js](https://nodejs.org/) (download LTS version)
- That's it!

### Step 1: Download the Project
1. Download this folder to your computer
2. Open Terminal (Mac/Linux) or Command Prompt (Windows)
3. Navigate to the project folder:
   ```bash
   cd path/to/quiz-app
   ```

### Step 2: Install Dependencies
```bash
npm install
```
This will take 2-3 minutes. Don't worry about warnings!

### Step 3: Set Up Firebase
Follow the same Firebase setup as Option 1 (Step 3 above)

### Step 4: Configure & Run
1. Edit `src/firebase.js` with your Firebase config
2. Run the app:
   ```bash
   npm start
   ```
3. Your browser will automatically open to `http://localhost:3000`

---

## 🎯 Your First Quiz

### Create Your Account:
1. Click "Sign Up"
2. Enter any email (doesn't need to be real in test mode)
3. Create a password (minimum 6 characters)
4. Click "Sign Up"

### Take the Quiz:
1. Click "Start Quiz Now!"
2. Answer 10 questions
3. Each question has 30 seconds
4. Click "Next Question" or it auto-submits

### View Results:
1. See your score
2. Review correct/wrong answers
3. Check your rank on leaderboard

---

## 🛠️ Common Issues & Fixes

### "Firebase is not configured"
**Fix:** You forgot to replace the placeholder values in `src/firebase.js`

### "Email already in use"
**Fix:** You already signed up with that email. Use login instead or use a different email.

### Page is blank / white screen
**Fix:** 
1. Open browser console (F12 or right-click → Inspect)
2. Look for red errors
3. Usually means Firebase config is wrong

### "Module not found"
**Fix:** Run `npm install` again

### Quiz won't start
**Fix:** Make sure:
1. You're logged in
2. You haven't already taken the quiz today
3. Firestore database is created in Firebase Console

---

## 📝 Testing Checklist

✅ Sign up with new account  
✅ Login works  
✅ Dashboard shows your email  
✅ Can start quiz  
✅ Timer counts down  
✅ Can select answers  
✅ Quiz submits after 10 questions  
✅ Results page shows score  
✅ Leaderboard displays  
✅ Can logout  
✅ Can't take quiz twice in one day  

---

## 🎨 Customize Your Quiz

### Add Your Own Questions:
1. Open `src/data/questions.js`
2. Copy this template:
```javascript
{
  id: 11, // Increment the ID
  question: "What is 2 + 2?",
  options: ["3", "4", "5", "6"],
  correctAnswer: 1, // Index of "4"
  difficulty: "easy"
}
```
3. Add it to the array
4. Save and refresh!

### Change App Name:
1. Open `src/components/Navbar.jsx`
2. Find `📚 QuizMaster`
3. Change to your name
4. Save and refresh!

### Change Colors:
1. Open `src/App.css`
2. Find `:root {` at the top
3. Change `--primary-color: #6366f1;` to any color
   - Use [color picker](https://htmlcolorcodes.com/)
4. Save and refresh!

---

## 🚀 Make It Public

### On Replit:
1. Your app is already public!
2. Share the URL from the browser bar
3. Anyone can access it

### On Your Computer:
**Option A - Vercel (Recommended):**
1. Install Vercel: `npm install -g vercel`
2. Run: `vercel`
3. Follow prompts
4. Get a public URL instantly!

**Option B - Netlify:**
1. Run: `npm run build`
2. Go to [netlify.com](https://netlify.com)
3. Drag the `build` folder to Netlify
4. Get a public URL!

---

## 📞 Need Help?

**Before asking for help:**
1. ✅ Check this guide again
2. ✅ Look for red errors in browser console (F12)
3. ✅ Make sure Firebase is properly set up
4. ✅ Verify you copied ALL config values

**Still stuck?**
- Read the full README.md
- Check Firebase documentation
- Review the code comments

---

## 🎉 Next Steps

Once your app is working:

1. **Add more questions** (at least 50-100 for a real app)
2. **Customize the design** (colors, fonts, layout)
3. **Add your logo** (replace emoji in navbar)
4. **Test with friends** (get feedback)
5. **Set up Firebase security rules** (see README.md)
6. **Add more features** (see Roadmap in README)

---

## 🏆 Congratulations!

You've successfully deployed your first full-stack web application!

Now you have:
- ✅ User authentication
- ✅ Database storage
- ✅ Real-time leaderboard
- ✅ Anti-cheat protection
- ✅ Mobile-responsive design
- ✅ Live website

**You're ready to start building your quiz business!** 🚀

---

**Remember:** Every expert was once a beginner. You've got this! 💪
