// Firebase configuration and initialization
// This file connects your app to Firebase services

import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

// TODO: Replace these placeholder values with your actual Firebase config
// You'll get these values from Firebase Console (see setup instructions below)
const firebaseConfig = {
  apiKey: "YOUR_API_KEY_HERE",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_APP_ID"
};

// Initialize Firebase app with your configuration
const app = initializeApp(firebaseConfig);

// Get Firebase Authentication instance
// This handles user login, signup, logout
export const auth = getAuth(app);

// Get Firestore Database instance
// This is where we store user data, scores, leaderboard
export const db = getFirestore(app);

/* 
 * SETUP INSTRUCTIONS:
 * 
 * 1. Go to https://console.firebase.google.com/
 * 2. Click "Add project" and create a new project
 * 3. Once created, click on the Web icon (</>) to add a web app
 * 4. Register your app with a nickname (e.g., "Quiz App")
 * 5. Copy the firebaseConfig object and replace the placeholder above
 * 6. In Firebase Console, go to "Authentication" → "Get Started"
 * 7. Enable "Email/Password" as a sign-in method
 * 8. Go to "Firestore Database" → "Create Database"
 * 9. Start in "Test mode" (we'll add security rules later)
 * 10. Choose a location close to your users
 * 
 * Your Firebase is now ready to use!
 */
