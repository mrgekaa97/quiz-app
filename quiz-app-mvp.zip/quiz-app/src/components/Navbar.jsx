// Navigation bar component
// Displays at the top of every page with logo and user actions

import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { auth } from '../firebase';
import { signOut } from 'firebase/auth';

const Navbar = ({ user }) => {
  const navigate = useNavigate();

  // Handle user logout
  const handleLogout = async () => {
    try {
      await signOut(auth); // Sign out from Firebase
      navigate('/login'); // Redirect to login page
    } catch (error) {
      console.error('Logout error:', error);
      alert('Failed to logout. Please try again.');
    }
  };

  return (
    <nav className="navbar">
      <div className="nav-container">
        {/* Logo/Brand */}
        <Link to="/dashboard" className="nav-logo">
          📚 QuizMaster
        </Link>

        {/* Navigation Links */}
        <div className="nav-links">
          {user ? (
            // Show these links when user is logged in
            <>
              <Link to="/dashboard" className="nav-link">Dashboard</Link>
              <Link to="/leaderboard" className="nav-link">Leaderboard</Link>
              <span className="nav-email">{user.email}</span>
              <button onClick={handleLogout} className="btn-logout">
                Logout
              </button>
            </>
          ) : (
            // Show these links when user is not logged in
            <>
              <Link to="/login" className="nav-link">Login</Link>
              <Link to="/signup" className="nav-link">Sign Up</Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
