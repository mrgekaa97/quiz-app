// Protected Route Component
// Prevents non-logged-in users from accessing protected pages
// Redirects to login if user is not authenticated

import React from 'react';
import { Navigate } from 'react-router-dom';

const ProtectedRoute = ({ user, children }) => {
  // If no user is logged in, redirect to login page
  if (!user) {
    return <Navigate to="/login" replace />;
  }

  // If user is logged in, show the requested page
  return children;
};

export default ProtectedRoute;
