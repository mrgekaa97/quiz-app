// Quiz Card Component
// Displays a single question with options and timer

import React from 'react';

const QuizCard = ({ 
  question, 
  currentQuestion, 
  totalQuestions, 
  selectedOption, 
  onOptionSelect, 
  timeLeft 
}) => {
  return (
    <div className="quiz-card">
      {/* Progress indicator */}
      <div className="quiz-progress">
        <span>Question {currentQuestion + 1} of {totalQuestions}</span>
        <span className={`timer ${timeLeft <= 10 ? 'timer-warning' : ''}`}>
          ⏱️ {timeLeft}s
        </span>
      </div>

      {/* Question text */}
      <h2 className="question-text">{question.question}</h2>

      {/* Answer options */}
      <div className="options-container">
        {question.options.map((option, index) => (
          <button
            key={index}
            className={`option-btn ${selectedOption === index ? 'selected' : ''}`}
            onClick={() => onOptionSelect(index)}
          >
            <span className="option-label">{String.fromCharCode(65 + index)}.</span>
            <span className="option-text">{option}</span>
          </button>
        ))}
      </div>

      {/* Difficulty badge */}
      <div className="difficulty-badge">
        Difficulty: <span className={`badge-${question.difficulty}`}>
          {question.difficulty}
        </span>
      </div>
    </div>
  );
};

export default QuizCard;
