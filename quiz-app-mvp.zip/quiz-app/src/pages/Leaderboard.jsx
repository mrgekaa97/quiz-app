// Leaderboard Page
// Displays top 10 users ranked by total score

import React, { useState, useEffect } from 'react';
import { collection, query, orderBy, limit, getDocs } from 'firebase/firestore';
import { db } from '../firebase';

const Leaderboard = ({ user }) => {
  const [leaders, setLeaders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [userRank, setUserRank] = useState(null);

  // Fetch leaderboard data
  useEffect(() => {
    const fetchLeaderboard = async () => {
      try {
        // Query Firestore for top 10 users by totalScore
        const leaderboardQuery = query(
          collection(db, 'users'),
          orderBy('totalScore', 'desc'), // Sort by score, highest first
          limit(10) // Get only top 10
        );

        const querySnapshot = await getDocs(leaderboardQuery);
        const leaderboardData = [];
        
        querySnapshot.forEach((doc) => {
          leaderboardData.push({
            id: doc.id,
            ...doc.data()
          });
        });

        setLeaders(leaderboardData);

        // Find current user's rank
        const currentUserIndex = leaderboardData.findIndex(
          leader => leader.userId === user?.uid
        );
        if (currentUserIndex !== -1) {
          setUserRank(currentUserIndex + 1);
        }
      } catch (error) {
        console.error('Error fetching leaderboard:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchLeaderboard();
  }, [user]);

  // Mask email for privacy (show only first 3 chars)
  const maskEmail = (email) => {
    if (!email) return 'Anonymous';
    const [name, domain] = email.split('@');
    return `${name.substring(0, 3)}***@${domain}`;
  };

  // Get medal emoji based on rank
  const getMedal = (rank) => {
    if (rank === 1) return '🥇';
    if (rank === 2) return '🥈';
    if (rank === 3) return '🥉';
    return `#${rank}`;
  };

  if (loading) {
    return (
      <div className="loading-container">
        <div className="spinner"></div>
        <p>Loading leaderboard...</p>
      </div>
    );
  }

  return (
    <div className="leaderboard-container">
      <div className="leaderboard-header">
        <h1>🏆 Leaderboard</h1>
        <p className="leaderboard-subtitle">Top Quiz Masters of All Time</p>
      </div>

      {/* User's Rank Display */}
      {userRank && (
        <div className="user-rank-card">
          <p>Your Current Rank: <strong>{getMedal(userRank)}</strong></p>
        </div>
      )}

      {/* Leaderboard Table */}
      <div className="leaderboard-card">
        {leaders.length === 0 ? (
          <div className="empty-leaderboard">
            <p>No scores yet. Be the first to take the quiz! 🎯</p>
          </div>
        ) : (
          <div className="leaderboard-table">
            {/* Table Header */}
            <div className="table-header">
              <div className="col-rank">Rank</div>
              <div className="col-user">User</div>
              <div className="col-score">Score</div>
            </div>

            {/* Table Rows */}
            {leaders.map((leader, index) => {
              const isCurrentUser = leader.userId === user?.uid;
              
              return (
                <div 
                  key={leader.id} 
                  className={`table-row ${isCurrentUser ? 'current-user' : ''} ${index < 3 ? 'top-three' : ''}`}
                >
                  <div className="col-rank">
                    <span className="rank-badge">{getMedal(index + 1)}</span>
                  </div>
                  <div className="col-user">
                    <span className="user-email">{maskEmail(leader.email)}</span>
                    {isCurrentUser && <span className="you-badge">You</span>}
                  </div>
                  <div className="col-score">
                    <span className="score-value">{leader.totalScore || 0}</span>
                    <span className="score-label">pts</span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Leaderboard Info */}
      <div className="leaderboard-info">
        <div className="info-card">
          <h3>How Rankings Work</h3>
          <ul>
            <li>📊 Rankings are based on total accumulated score</li>
            <li>🔄 Leaderboard updates in real-time</li>
            <li>🎯 Complete daily quizzes to climb the ranks</li>
            <li>🔒 Email addresses are partially hidden for privacy</li>
          </ul>
        </div>

        <div className="info-card">
          <h3>Coming Soon</h3>
          <ul>
            <li>🏅 Weekly tournaments with prizes</li>
            <li>👥 Friend competitions</li>
            <li>📈 Detailed performance analytics</li>
            <li>🎁 Rewards for top performers</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default Leaderboard;
