// Quiz Page
// Main quiz gameplay with timer, question navigation, and anti-cheat

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { doc, getDoc, updateDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../firebase';
import QuizCard from '../components/QuizCard';
import { quizQuestions, shuffleQuestions } from '../data/questions';

const Quiz = ({ user }) => {
  const navigate = useNavigate();

  // Quiz state
  const [questions, setQuestions] = useState([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState(null);
  const [answers, setAnswers] = useState([]); // Store all user answers
  const [timeLeft, setTimeLeft] = useState(30); // 30 seconds per question
  const [quizStarted, setQuizStarted] = useState(false);
  const [quizLocked, setQuizLocked] = useState(false);

  // Initialize quiz
  useEffect(() => {
    const initializeQuiz = async () => {
      try {
        // Check if user already attempted today (anti-cheat)
        const userDoc = await getDoc(doc(db, 'users', user.uid));
        const userData = userDoc.data();

        const today = new Date().toDateString();
        const lastAttempt = userData.lastAttemptDate?.toDate().toDateString();

        // If user already attempted today, redirect to dashboard
        if (lastAttempt === today) {
          alert('You have already completed today\'s quiz! Come back tomorrow.');
          navigate('/dashboard');
          return;
        }

        // Shuffle questions to prevent memorization
        const shuffled = shuffleQuestions(quizQuestions);
        setQuestions(shuffled);
        setQuizStarted(true);
      } catch (error) {
        console.error('Error initializing quiz:', error);
        alert('Failed to load quiz. Please try again.');
        navigate('/dashboard');
      }
    };

    initializeQuiz();
  }, [user, navigate]);

  // Timer countdown effect
  useEffect(() => {
    if (!quizStarted || quizLocked) return;

    // Only run timer if there are questions and quiz hasn't ended
    if (questions.length === 0) return;

    const timer = setInterval(() => {
      setTimeLeft((prevTime) => {
        if (prevTime <= 1) {
          // Time's up - automatically submit current answer
          handleNextQuestion();
          return 30; // Reset timer for next question
        }
        return prevTime - 1;
      });
    }, 1000); // Run every 1 second

    // Cleanup timer when component unmounts or question changes
    return () => clearInterval(timer);
  }, [timeLeft, quizStarted, currentQuestionIndex, questions.length, quizLocked]);

  // Prevent page refresh/back button during quiz (anti-cheat)
  useEffect(() => {
    const handleBeforeUnload = (e) => {
      if (quizStarted && !quizLocked) {
        e.preventDefault();
        e.returnValue = 'Your quiz progress will be lost. Are you sure?';
      }
    };

    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [quizStarted, quizLocked]);

  // Handle option selection
  const handleOptionSelect = (optionIndex) => {
    setSelectedOption(optionIndex);
  };

  // Handle moving to next question
  const handleNextQuestion = () => {
    // Save current answer
    const currentAnswer = {
      questionId: questions[currentQuestionIndex].id,
      selectedOption: selectedOption,
      correctAnswer: questions[currentQuestionIndex].correctAnswer,
      isCorrect: selectedOption === questions[currentQuestionIndex].correctAnswer
    };

    setAnswers([...answers, currentAnswer]);

    // Check if this was the last question
    if (currentQuestionIndex === questions.length - 1) {
      // Quiz finished - calculate and save results
      finishQuiz([...answers, currentAnswer]);
    } else {
      // Move to next question
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setSelectedOption(null); // Reset selection
      setTimeLeft(30); // Reset timer
    }
  };

  // Calculate score and save to database
  const finishQuiz = async (allAnswers) => {
    setQuizLocked(true);

    // Calculate score
    const correctAnswers = allAnswers.filter(answer => answer.isCorrect).length;
    const totalQuestions = questions.length;
    const score = Math.round((correctAnswers / totalQuestions) * 100);

    try {
      // Update user data in Firestore
      const userRef = doc(db, 'users', user.uid);
      const userDoc = await getDoc(userRef);
      const currentTotal = userDoc.data().totalScore || 0;

      await updateDoc(userRef, {
        totalScore: currentTotal + score,
        lastAttemptDate: serverTimestamp(),
        attemptsToday: 1
      });

      // Navigate to result page with score data
      navigate('/result', {
        state: {
          score: score,
          correctAnswers: correctAnswers,
          totalQuestions: totalQuestions,
          answers: allAnswers
        }
      });
    } catch (error) {
      console.error('Error saving quiz results:', error);
      alert('Failed to save your results. Please contact support.');
    }
  };

  // Show loading state
  if (!quizStarted || questions.length === 0) {
    return (
      <div className="loading-container">
        <div className="spinner"></div>
        <p>Loading quiz...</p>
      </div>
    );
  }

  const currentQuestion = questions[currentQuestionIndex];

  return (
    <div className="quiz-container">
      {/* Quiz Header */}
      <div className="quiz-header">
        <h1>🎯 Quiz Challenge</h1>
        <div className="quiz-progress-bar">
          <div 
            className="progress-fill" 
            style={{ width: `${((currentQuestionIndex + 1) / questions.length) * 100}%` }}
          ></div>
        </div>
      </div>

      {/* Quiz Question Card */}
      <QuizCard
        question={currentQuestion}
        currentQuestion={currentQuestionIndex}
        totalQuestions={questions.length}
        selectedOption={selectedOption}
        onOptionSelect={handleOptionSelect}
        timeLeft={timeLeft}
      />

      {/* Next Button */}
      <div className="quiz-actions">
        <button
          className="btn-next"
          onClick={handleNextQuestion}
          disabled={selectedOption === null}
        >
          {currentQuestionIndex === questions.length - 1 ? 'Finish Quiz' : 'Next Question'} →
        </button>
        {selectedOption === null && (
          <p className="selection-hint">Please select an answer to continue</p>
        )}
      </div>

      {/* Quiz Info */}
      <div className="quiz-info-footer">
        <p>⚠️ Cannot go back to previous questions</p>
        <p>⏰ Each question auto-submits after 30 seconds</p>
      </div>
    </div>
  );
};

export default Quiz;
