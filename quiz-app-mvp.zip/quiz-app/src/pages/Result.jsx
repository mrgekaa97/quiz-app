// Result Page
// Displays quiz results with score, performance message, and review

import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

const Result = () => {
  const location = useLocation();
  const navigate = useNavigate();

  // Get quiz results from navigation state
  const { score, correctAnswers, totalQuestions, answers } = location.state || {};

  // If no results data, redirect to dashboard
  if (!location.state) {
    navigate('/dashboard');
    return null;
  }

  // Determine performance message and emoji based on score
  const getPerformanceMessage = () => {
    if (score >= 90) {
      return { message: 'Outstanding! You\'re a Quiz Master! 🏆', color: '#FFD700' };
    } else if (score >= 70) {
      return { message: 'Great Job! Keep it up! 🌟', color: '#4CAF50' };
    } else if (score >= 50) {
      return { message: 'Good Effort! Room for improvement! 💪', color: '#2196F3' };
    } else {
      return { message: 'Keep Learning! Practice makes perfect! 📚', color: '#FF9800' };
    }
  };

  const performance = getPerformanceMessage();

  return (
    <div className="result-container">
      {/* Result Card */}
      <div className="result-card">
        <div className="result-header">
          <h1>Quiz Completed! 🎉</h1>
          <p className="result-subtitle">Here's how you performed</p>
        </div>

        {/* Score Display */}
        <div className="score-display" style={{ borderColor: performance.color }}>
          <div className="score-circle">
            <svg viewBox="0 0 200 200">
              <circle
                cx="100"
                cy="100"
                r="90"
                fill="none"
                stroke="#e0e0e0"
                strokeWidth="20"
              />
              <circle
                cx="100"
                cy="100"
                r="90"
                fill="none"
                stroke={performance.color}
                strokeWidth="20"
                strokeDasharray={`${score * 5.65} 565`}
                strokeLinecap="round"
                transform="rotate(-90 100 100)"
              />
            </svg>
            <div className="score-text">
              <h2>{score}%</h2>
            </div>
          </div>
        </div>

        {/* Performance Message */}
        <div className="performance-message" style={{ color: performance.color }}>
          <h3>{performance.message}</h3>
        </div>

        {/* Stats Summary */}
        <div className="stats-summary">
          <div className="stat-item">
            <span className="stat-label">Correct Answers</span>
            <span className="stat-number">{correctAnswers}/{totalQuestions}</span>
          </div>
          <div className="stat-item">
            <span className="stat-label">Wrong Answers</span>
            <span className="stat-number">{totalQuestions - correctAnswers}/{totalQuestions}</span>
          </div>
          <div className="stat-item">
            <span className="stat-label">Accuracy</span>
            <span className="stat-number">{score}%</span>
          </div>
        </div>

        {/* Answer Review */}
        <div className="answer-review">
          <h3>📋 Answer Review</h3>
          <div className="review-list">
            {answers.map((answer, index) => (
              <div 
                key={index} 
                className={`review-item ${answer.isCorrect ? 'correct' : 'incorrect'}`}
              >
                <div className="review-question">
                  Question {index + 1}
                  <span className={`review-badge ${answer.isCorrect ? 'badge-correct' : 'badge-wrong'}`}>
                    {answer.isCorrect ? '✓ Correct' : '✗ Wrong'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="result-actions">
          <button 
            className="btn-primary" 
            onClick={() => navigate('/dashboard')}
          >
            Back to Dashboard
          </button>
          <button 
            className="btn-secondary" 
            onClick={() => navigate('/leaderboard')}
          >
            View Leaderboard
          </button>
        </div>

        {/* Next Attempt Info */}
        <div className="next-attempt-info">
          <p>🕐 Come back tomorrow for a new quiz challenge!</p>
          <p className="pro-tip">💡 Pro Tip: Check the leaderboard to see how you rank!</p>
        </div>
      </div>
    </div>
  );
};

export default Result;
