// Dashboard Page
// Main page after login - shows user stats and quiz access

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../firebase';

const Dashboard = ({ user }) => {
  const [userData, setUserData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [canTakeQuiz, setCanTakeQuiz] = useState(false);
  
  const navigate = useNavigate();

  // Load user data when component mounts
  useEffect(() => {
    const fetchUserData = async () => {
      try {
        // Get user document from Firestore
        const userDoc = await getDoc(doc(db, 'users', user.uid));
        
        if (userDoc.exists()) {
          const data = userDoc.data();
          setUserData(data);

          // Check if user can take quiz today
          const today = new Date().toDateString();
          const lastAttempt = data.lastAttemptDate?.toDate().toDateString();
          
          // Allow quiz if:
          // 1. User never attempted before (lastAttemptDate is null)
          // 2. Last attempt was on a different day
          if (!data.lastAttemptDate || lastAttempt !== today) {
            setCanTakeQuiz(true);
          } else {
            setCanTakeQuiz(false);
          }
        }
      } catch (error) {
        console.error('Error fetching user data:', error);
      } finally {
        setLoading(false);
      }
    };

    if (user) {
      fetchUserData();
    }
  }, [user]);

  // Navigate to quiz page
  const startQuiz = () => {
    navigate('/quiz');
  };

  // Navigate to leaderboard
  const viewLeaderboard = () => {
    navigate('/leaderboard');
  };

  if (loading) {
    return (
      <div className="loading-container">
        <div className="spinner"></div>
        <p>Loading your dashboard...</p>
      </div>
    );
  }

  return (
    <div className="dashboard-container">
      <div className="welcome-section">
        <h1>Welcome back! 👋</h1>
        <p className="user-email">{user?.email}</p>
      </div>

      {/* User Stats Cards */}
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon">🏆</div>
          <div className="stat-info">
            <h3>Total Score</h3>
            <p className="stat-value">{userData?.totalScore || 0}</p>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon">📝</div>
          <div className="stat-info">
            <h3>Subscription</h3>
            <p className="stat-value">{userData?.subscriptionType || 'Free'}</p>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon">🎯</div>
          <div className="stat-info">
            <h3>Attempts Today</h3>
            <p className="stat-value">{canTakeQuiz ? '0/1' : '1/1'}</p>
          </div>
        </div>
      </div>

      {/* Quiz Start Section */}
      <div className="quiz-section">
        <div className="quiz-card-large">
          <h2>📚 Daily Quiz Challenge</h2>
          <p className="quiz-description">
            Test your knowledge with 10 challenging questions. 
            You have 30 seconds per question!
          </p>

          {canTakeQuiz ? (
            <div>
              <button className="btn-start-quiz" onClick={startQuiz}>
                Start Quiz Now! 🚀
              </button>
              <p className="quiz-info">✅ You have 1 free attempt today</p>
            </div>
          ) : (
            <div className="quiz-locked">
              <p className="locked-message">🔒 You've already completed today's quiz!</p>
              <p className="locked-info">Come back tomorrow for a new challenge</p>
              <button className="btn-secondary" onClick={viewLeaderboard}>
                View Leaderboard
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Features Section */}
      <div className="features-section">
        <h3>Why QuizMaster?</h3>
        <div className="features-grid">
          <div className="feature-item">
            <span className="feature-icon">📖</span>
            <h4>Learn Daily</h4>
            <p>New questions every day to expand your knowledge</p>
          </div>
          <div className="feature-item">
            <span className="feature-icon">🏅</span>
            <h4>Compete</h4>
            <p>Challenge yourself and climb the leaderboard</p>
          </div>
          <div className="feature-item">
            <span className="feature-icon">⚡</span>
            <h4>Track Progress</h4>
            <p>Monitor your scores and improvement over time</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
