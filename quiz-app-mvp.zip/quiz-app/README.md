# 📚 QuizMaster - Educational Quiz App MVP

A complete educational quiz web application built with React and Firebase. Users can take daily quizzes, track scores, and compete on the leaderboard.

## ✨ Features

### Core Features
- ✅ **User Authentication** - Email/password signup and login via Firebase
- ✅ **Daily Quiz System** - 10 questions with 30-second timer per question
- ✅ **Score Tracking** - Automatic score calculation and storage
- ✅ **Leaderboard** - Real-time rankings of top performers
- ✅ **Anti-Cheat Logic** - One attempt per day, prevents page refresh during quiz
- ✅ **Responsive Design** - Works perfectly on mobile, tablet, and desktop

### Security Features
- 🔒 Protected routes (only logged-in users can access quiz)
- 🔒 Prevents multiple daily attempts
- 🔒 Session lock during quiz (prevents refresh)
- 🔒 Email masking on leaderboard for privacy

### Future-Ready Architecture
- 💰 Subscription system structure (free/premium)
- 💰 Attempts tracking (ready for monetization)
- 📊 User profile system extensible for more features

## 🛠️ Tech Stack

- **Frontend**: React 18 (functional components + hooks)
- **Backend**: Firebase (Authentication + Firestore Database)
- **Routing**: React Router v6
- **Styling**: Custom CSS (mobile-first responsive design)
- **Hosting**: Compatible with Replit, Vercel, Netlify

## 📁 Project Structure

```
quiz-app/
├── public/
│   └── index.html              # Main HTML file
├── src/
│   ├── components/
│   │   ├── Navbar.jsx          # Navigation bar
│   │   ├── ProtectedRoute.jsx  # Route protection wrapper
│   │   └── QuizCard.jsx        # Question display component
│   ├── pages/
│   │   ├── Login.jsx           # Login page
│   │   ├── Signup.jsx          # Registration page
│   │   ├── Dashboard.jsx       # Main dashboard
│   │   ├── Quiz.jsx            # Quiz gameplay
│   │   ├── Result.jsx          # Results display
│   │   └── Leaderboard.jsx     # Rankings
│   ├── data/
│   │   └── questions.js        # Quiz questions database
│   ├── firebase.js             # Firebase configuration
│   ├── App.jsx                 # Main app component
│   ├── App.css                 # Main styles
│   ├── index.js                # React entry point
│   └── index.css               # Global styles
├── package.json
└── README.md
```

## 🚀 Setup Instructions

### Step 1: Set Up Firebase

1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Click **"Add project"**
3. Enter a project name (e.g., "quiz-app")
4. Disable Google Analytics (optional)
5. Click **"Create project"**

### Step 2: Enable Firebase Services

#### Enable Authentication:
1. In Firebase Console, click **"Authentication"** from the left menu
2. Click **"Get started"**
3. Click **"Email/Password"** under Sign-in method
4. Toggle **"Enable"** and click **"Save"**

#### Enable Firestore Database:
1. Click **"Firestore Database"** from the left menu
2. Click **"Create database"**
3. Select **"Start in test mode"** (we'll add security rules later)
4. Choose a location close to your users
5. Click **"Enable"**

### Step 3: Get Firebase Configuration

1. In Firebase Console, click the **gear icon** ⚙️ next to "Project Overview"
2. Click **"Project settings"**
3. Scroll down to **"Your apps"**
4. Click the **web icon** `</>`
5. Register your app with a nickname (e.g., "QuizMaster Web")
6. Copy the `firebaseConfig` object

### Step 4: Configure the Project

1. Open `src/firebase.js`
2. Replace the placeholder values with your Firebase config:

```javascript
const firebaseConfig = {
  apiKey: "YOUR_API_KEY_HERE",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_APP_ID"
};
```

### Step 5: Install Dependencies

**On your local machine:**
```bash
npm install
```

**On Replit:**
1. Import this project to Replit
2. Replit will automatically install dependencies
3. Click "Run" button

### Step 6: Run the Application

**Locally:**
```bash
npm start
```
The app will open at `http://localhost:3000`

**On Replit:**
1. Click the **"Run"** button
2. The app will open in the Replit preview window
3. Click **"Open in new tab"** for full experience

## 🎮 How to Use

### For Users:

1. **Sign Up**: Create an account with email and password
2. **Dashboard**: View your stats and start quiz
3. **Take Quiz**: Answer 10 questions (30 seconds each)
4. **View Results**: See your score and review answers
5. **Leaderboard**: Check your ranking against other users
6. **Daily Limit**: Come back tomorrow for a new quiz

### For Developers:

#### Adding More Questions:
Edit `src/data/questions.js`:
```javascript
{
  id: 11,
  question: "Your question here?",
  options: ["Option A", "Option B", "Option C", "Option D"],
  correctAnswer: 0, // Index of correct option (0-3)
  difficulty: "easy" // easy, medium, or hard
}
```

#### Changing Quiz Settings:
In `src/pages/Quiz.jsx`:
- **Timer duration**: Change `setTimeLeft(30)` to desired seconds
- **Number of questions**: Questions array is automatically used

#### Modifying Daily Attempt Limit:
In `src/pages/Dashboard.jsx` and `src/pages/Quiz.jsx`:
- Look for date comparison logic
- Modify to allow more attempts (for premium users, etc.)

## 🔐 Firebase Security Rules

Once your app is live, update Firestore security rules:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Users collection
    match /users/{userId} {
      // Users can only read/write their own data
      allow read: if request.auth != null;
      allow write: if request.auth != null && request.auth.uid == userId;
    }
  }
}
```

To update rules:
1. Go to Firestore Database in Firebase Console
2. Click **"Rules"** tab
3. Paste the rules above
4. Click **"Publish"**

## 📱 Mobile Optimization

The app is fully responsive and works on:
- ✅ Desktop (1200px+)
- ✅ Tablet (768px - 1199px)
- ✅ Mobile (320px - 767px)

## 🎨 Customization

### Change Color Theme:
Edit CSS variables in `src/App.css`:
```css
:root {
  --primary-color: #6366f1; /* Your brand color */
  --secondary-color: #10b981;
  --danger-color: #ef4444;
  /* ... more colors */
}
```

### Modify Logo:
In `src/components/Navbar.jsx`:
```jsx
<Link to="/dashboard" className="nav-logo">
  📚 QuizMaster  {/* Change emoji and text */}
</Link>
```

## 🚀 Deployment

### Deploy to Vercel:
```bash
npm install -g vercel
vercel
```

### Deploy to Netlify:
```bash
npm run build
# Drag and drop the 'build' folder to Netlify
```

### Deploy on Replit:
1. Click **"Deploy"** button in Replit
2. Choose deployment type
3. Your app will be live with a public URL

## 💰 Monetization Strategy (Future)

The codebase is structured to easily add:

1. **Premium Subscriptions**:
   - Modify `subscriptionType` in user profile
   - Allow unlimited attempts for premium users
   - Add payment integration (Stripe)

2. **Paid Tournaments**:
   - Create special quiz collections
   - Add entry fee logic
   - Implement prize distribution

3. **Rewards System**:
   - Track user achievements
   - Offer badges and certificates
   - Implement referral bonuses

## 🐛 Troubleshooting

### "Firebase not configured" error:
- Make sure you replaced ALL placeholder values in `firebase.js`
- Check if Firebase services are enabled in console

### "Cannot read property 'uid' of null":
- User is not logged in
- Check if authentication is properly set up

### Quiz not loading:
- Check browser console for errors
- Verify Firestore database is created
- Ensure questions.js has valid data

### Timer not working:
- Check browser console for JavaScript errors
- Verify Quiz.jsx timer logic is intact

## 📊 Database Structure

### Users Collection (`users/{userId}`):
```javascript
{
  userId: "firebase-auth-uid",
  email: "user@example.com",
  createdAt: Timestamp,
  totalScore: 150,
  attemptsToday: 1,
  lastAttemptDate: Timestamp,
  subscriptionType: "free",
  attemptsRemaining: 0
}
```

## 🎯 Roadmap

- [ ] Add difficulty-based scoring
- [ ] Implement streak tracking
- [ ] Add social sharing features
- [ ] Create admin panel for question management
- [ ] Add detailed analytics dashboard
- [ ] Implement category-based quizzes
- [ ] Add multiplayer mode
- [ ] Create mobile app (React Native)

## 📝 License

This project is open source and available for educational purposes.

## 👨‍💻 Support

For questions or issues:
1. Check this README first
2. Review Firebase documentation
3. Check browser console for errors
4. Review the commented code

## 🎉 Congratulations!

You now have a fully functional quiz app MVP ready to launch and scale into a real business!

---

**Built with ❤️ using React and Firebase**
